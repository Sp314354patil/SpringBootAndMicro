package com.ig.beans;

import java.util.Date;

public class WishMessageGenerator {

	// pre defined class  <bean 
	private Date date; // dependent composition HAS-A 

	public WishMessageGenerator() {
		super();
		//this.date = date;
	}
	
	
	// we are interested to use setter injection
	public void setDate(Date date) {
		this.date = date;
	}
	
	public void getMessage(String name) {
		int hrs = date.getHours(); // deprecated
		
		if(hrs>0 && hrs <12) 
			System.out.println("Good  Morning "+name);
		else if (hrs > 12 && hrs <16)
			System.out.println("Good  Afternoon "+name);
		else if (hrs >16 && hrs <20)
			System.out.println("Good  Evening "+name);
		else
			System.out.println("Good  Night "+name);
	}
	
}


